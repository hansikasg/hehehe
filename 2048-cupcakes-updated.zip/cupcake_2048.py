import tkinter as tk
from tkinter import messagebox
import random
from PIL import Image, ImageTk

SIZE = 4
TILE_SIZE = 100
GAP = 10
IMAGE_PATH = "images/"
TILE_VALUES = [0, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048]

class Cupcake2048:
    def __init__(self, master):
        self.master = master
        self.master.title("🧁 2048 Cupcakes")
        self.board = [[0] * SIZE for _ in range(SIZE)]
        self.images = {}
        self.canvas = tk.Canvas(master, width=SIZE * (TILE_SIZE + GAP) + GAP,
                                height=SIZE * (TILE_SIZE + GAP) + GAP, bg="#f8f8f8")
        self.canvas.pack()
        self.load_images()
        self.start_game()
        self.master.bind("<Key>", self.key_handler)

    def load_images(self):
        for val in TILE_VALUES:
            try:
                if val == 0:
                    img = Image.new("RGBA", (TILE_SIZE, TILE_SIZE), (240, 240, 240, 255))
                else:
                    img = Image.open(f"{IMAGE_PATH}{val}.png").resize((TILE_SIZE, TILE_SIZE))
                self.images[val] = ImageTk.PhotoImage(img)
            except:
                img = Image.new("RGBA", (TILE_SIZE, TILE_SIZE), (255, 0, 0, 255))
                self.images[val] = ImageTk.PhotoImage(img)

    def start_game(self):
        self.add_tile()
        self.add_tile()
        self.draw_board()

    def draw_board(self):
        self.canvas.delete("all")
        for r in range(SIZE):
            for c in range(SIZE):
                x = c * (TILE_SIZE + GAP) + GAP
                y = r * (TILE_SIZE + GAP) + GAP
                val = self.board[r][c]
                img = self.images.get(val, self.images[0])
                self.canvas.create_image(x, y, anchor="nw", image=img)

    def add_tile(self):
        empty = [(r, c) for r in range(SIZE) for c in range(SIZE) if self.board[r][c] == 0]
        if empty:
            r, c = random.choice(empty)
            self.board[r][c] = 2 if random.random() < 0.9 else 4

    def compress_and_merge(self, row):
        new = [i for i in row if i != 0]
        i = 0
        while i < len(new)-1:
            if new[i] == new[i+1]:
                new[i] *= 2
                new.pop(i+1)
                new.append(0)
            i += 1
        return new + [0] * (SIZE - len(new))

    def move(self, dir):
        moved = False
        temp_board = [row[:] for row in self.board]
        for _ in range(dir):
            self.board = [list(row) for row in zip(*self.board[::-1])]
        for i in range(SIZE):
            new_row = self.compress_and_merge(self.board[i])
            if new_row != self.board[i]:
                moved = True
                self.board[i] = new_row
        for _ in range((4 - dir) % 4):
            self.board = [list(row) for row in zip(*self.board[::-1])]
        if moved:
            self.add_tile()
            self.draw_board()
            if self.check_game_over():
                messagebox.showinfo("Game Over", "No more cupcake moves!")

    def key_handler(self, event):
        keys = {"Up": 0, "Right": 1, "Down": 2, "Left": 3}
        if event.keysym in keys:
            self.move(keys[event.keysym])

    def check_game_over(self):
        for r in range(SIZE):
            for c in range(SIZE):
                if self.board[r][c] == 0:
                    return False
                if c + 1 < SIZE and self.board[r][c] == self.board[r][c+1]:
                    return False
                if r + 1 < SIZE and self.board[r][c] == self.board[r+1][c]:
                    return False
        return True

if __name__ == "__main__":
    root = tk.Tk()
    game = Cupcake2048(root)
    root.mainloop()
