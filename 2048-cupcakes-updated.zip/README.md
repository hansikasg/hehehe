# 🧁 2048 Cupcakes

For the 2048 cupcake queens - Combine matching cupcakes to discover fancier flavors and reach the ultimate **Rainbow Surprise** cupcake 🎉.

## 🍰 Features
- Cute cupcake images for each tile
- Simple and fun UI using Python and Tkinter
- Reach `2048` to win!

## 🛠 Requirements

- Python 3.6+
- Pillow for image handling:
  ```
  pip install pillow
  ```

## 🎮 How to Play

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/2048-cupcakes.git
   cd 2048-cupcakes
   ```

2. Run the game:
   ```
   python cupcake_2048.py
   ```

3. Use arrow keys (↑ ↓ ← →) to move the tiles.

## 📸 Cupcake Images

Add your cupcake tile images (e.g., `2.png`, `4.png`, ..., `2048.png`) in the `images/` folder.  
Images should be ~100x100 pixels.

## 📜 License

MIT License
